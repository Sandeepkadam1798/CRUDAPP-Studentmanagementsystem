export const tourData = [
  {
    id: 1,
    city: "new york",
    img: "./img/newyork.jpeg",
    name: "new york tour",
    info:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel,repellendus!"
  },
  {
    id: 2,
    city: "paris",
    img: "./img/paris.jpeg",
    name: "paris tour",
    info:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel,repellendus!"
  },
  {
    id: 3,
    city: "london",
    img: "./img/london.jpeg",
    name: "london tour",
    info:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel,repellendus!"
  },
  {
    id: 4,
    city: "tokyo",
    img: "./img/tokyo.jpeg",
    name: "tokyo tour",
    info:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel,repellendus!"
  },
  {
    id: 5,
    city: "la rochelle",
    img: "./img/la-rochelle.jpg",
    name: "la rochelle tour",
    info:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel,repellendus!"
  },
  {
    id: 6,
    city: "niort",
    img: "./img/niort.jpg",
    name: "niort tour",
    info:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel,repellendus!"
  },
  {
    id: 7,
    city: "bordeaux",
    img: "./img/bordeaux.jpg",
    name: "bordeaux tour",
    info:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel,repellendus!"
  },
  {
    id: 8,
    city: "nantes",
    img: "./img/nantes2.jpg",
    name: "nantes tour",
    info:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel,repellendus!"
  }
];
