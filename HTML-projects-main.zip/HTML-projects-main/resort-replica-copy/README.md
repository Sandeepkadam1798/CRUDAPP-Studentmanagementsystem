# resort-replica
The replica of the website of a resort using HTML and CSS only.
